<?php

	session_start();
	include "db_con.php";
	$msg="";
	$obj=new help();
	
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
		$address=$_REQUEST['address'];
		$district=$_REQUEST['district'];
		$city=$_REQUEST['city'];
		$date=$_REQUEST['date'];
		$phone_number=$_REQUEST['phone_number'];
		$email_id=$_REQUEST['email_id'];
		
		
		$sql="insert into blood_camp values (NULL,'".$address."','".$district."','".$city."','".$date."','".$phone_number."','".$email_id."')";
	
		mysql_query($sql);
		
		$msg="<div style='background:orange;width:200px;height:30px;border:1px solid black;'> Data updated complete.</div>";
		
	}
	

?>

<html>
<head>
<title> My project</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Copyright" content="arirusmanto.com">
<meta name="description" content="Admin MOS Template">
<meta name="keywords" content="Admin Page">
<meta name="author" content="Ari Rusmanto">
<meta name="language" content="Bahasa Indonesia">

<link rel="shortcut icon" href="stylesheet/img/devil-icon.png"> <!--Pemanggilan gambar favicon-->
<link rel="stylesheet" type="text/css" href="mos-css/mos-style.css"> <!--pemanggilan file css-->
</head>

<body>
<?php
	include "header.php";

?>

<div id="wrapper">
	<?php
	
		include "left.php";
	
	?>
	<div id="rightContent">
	<h3>ONLINE_BLOOD_BANK</h3>
	<div class="quoteOfDay">
	<b>Save The Life :</b><br>
	<i style="color: #5b5b5b;">"you really can,Donate your blood"</i>
	</div>
		
		  
		<form name="form1" method="post" action="">
        	<table border="1">
            
                 
			
				<tr>
                <td>address</td>
                <td>:</td>
                <td><input type="text" name="address" id="address" /></td>
                </tr>	
				<tr>
                <td>district</td>
                <td>:</td>
                <td><input type="text" name="district" id="district" /></td>
                </tr>	
				<tr>
                <td>city</td>
                <td>:</td>
                <td><input type="text" name="city" id="city" /></td>
                </tr>
				<tr>
                <td>date</td>
                <td>:</td>
                <td><input type="date" name="date" id="date" /></td>
                </tr>
				<tr>
                <td>phone number</td>
                <td>:</td>
                <td><input type="text" name="phone_number" id="phone_number" /></td>
                </tr>
				<tr>
                <td>email id</td>
                <td>:</td>
                <td><input type="text" name="email_id" id="email_id" /></td>
                </tr>
              
                <tr>
                <td><input type="submit" name="s1" value="Submit"/></td>
                <td>:</td>
                <td><input type="reset" name="s2"/></td>
                </tr>
            
            </table>
        
        
	  </form>
      <div><?php echo $msg;?></div>
	  <div class="clear"></div>
      
	</div>
<div class="clear"></div>
<?php

	include "footer.php";
?>
</div>
</body>
</html>