<?php

	session_start();
	include "db_con.php";
	$msg="";
	$obj=new help();
	$id=$_REQUEST['id'];
	
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
		$title=$_REQUEST['title'];
		$details=$_REQUEST['details'];	
		$sql="update home set title='".$title."', details='".$details."' where id='".$id."'";
		echo $sql;
		mysql_query($sql);
		
		$msg="<div style='background:orange;width:200px;height:30px;border:1px solid black;'>Data updated.</div>";
		
	}
	
	$sql1="select * from home where id='".$id."'";
	$rs=mysql_query($sql1);
	$d=mysql_fetch_array($rs);
?>

<html>
<head>
<title>Myproject</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Copyright" content="arirusmanto.com">
<meta name="description" content="Admin MOS Template">
<meta name="keywords" content="Admin Page">
<meta name="author" content="Ari Rusmanto">
<meta name="language" content="Bahasa Indonesia">

<link rel="shortcut icon" href="stylesheet/img/devil-icon.png"> <!--Pemanggilan gambar favicon-->
<link rel="stylesheet" type="text/css" href="mos-css/mos-style.css"> <!--pemanggilan file css-->
</head>

<body>
<?php
	include "header.php";

?>

<div id="wrapper">
	<?php
	
		include "left.php";
	
	?>
	<div id="rightContent">
	<h3>Dashboard</h3>
	<div class="quoteOfDay">
	<b>Quote of the day :</b><br>
	<i style="color: #5b5b5b;">"If you think you can, you really can"</i>
	</div>	
		
		  
		<form name="form1" method="post" action="">
        	<table border="1">
            
            	<tr>
                <td>Title</td>
                <td>:</td>
                <td><input type="text" name="title" id="title" value="<?php echo $d['title'];?>"/></td>
            	</tr>
                <tr>
                <td>Description</td>
                <td>:</td>
                <td><textarea name="details" id="details"><?php echo $d['details'];?></textarea></td>
                </tr>
                <tr>
                <td><input type="submit" name="s1" value="Submit"/></td>
                <td>:</td>
                <td><input type="reset" name="s2"/></td>
                </tr>
            </table>
        
        
	  </form>
      <div><?php echo $msg;?></div>
	  <div class="clear"></div>
      
	</div>
<div class="clear"></div>
<?php

	include "footer.php";
?>
</div>
</body>
</html>