<div id="leftBar">
	<ul>
		<li><a href="home.php">Home</a></li>
		<li><a href="about.php">About</a></li>
      	<li><a href="contact.php">Contact</a></li>
		<li><a href="gallery.php">Gellary</a></li>
		<li><a href="blood_master.php">blood_master</a></li>
		<li><a href="blood_bank.php">blood_bank</a></li>
		<li><a href="blood_camp.php">blood_camp</a></li>
		<li><a href="register_donor.php">Register_Donor</a></li>
		
       
	</ul>
	</div>