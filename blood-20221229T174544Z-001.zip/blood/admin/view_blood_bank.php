<?php

	session_start();
	include "db_con.php";
	$obj=new help();
?>

<html>
<head>
<title>Myproject</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Copyright" content="arirusmanto.com">
<meta name="description" content="Admin MOS Template">
<meta name="keywords" content="Admin Page">
<meta name="author" content="Ari Rusmanto">
<meta name="language" content="Bahasa Indonesia">

<link rel="shortcut icon" href="stylesheet/img/devil-icon.png"> <!--Pemanggilan gambar favicon-->
<link rel="stylesheet" type="text/css" href="mos-css/mos-style.css"> <!--pemanggilan file css-->
</head>

<body>
<?php
	include "header.php";

?>

<div id="wrapper">
	<?php
	
		include "left.php";
	
	?>
	<div id="rightContent">
	<h3>ONLINE_BLOOD_BANK</h3>
	<div class="quoteOfDay">
	<b>Save The Life :</b><br>
	<i style="color: #5b5b5b;">"you really can,Donate your blood"</i>
	</div>
		
		  
		<table border="1">
        	<tr>
            	
                <td>bank_name</td>
                <td>bank_add</td>
				<td>bank_email</td>
				<td>bank_phone</td>
				<td>Edit</td>
				<td>Delete</td>
				                
            </tr>
            <?php
			$sql="select * from blood_bank";
			$rs=mysql_query($sql);
			while($d=mysql_fetch_array($rs))
			{
			?>
            <tr>
            	
                <td><?php echo $d['bank_name'];?></td>
				 <td><?php echo $d['bank_add'];?></td>
				 <td><?php echo $d['bank_email'];?></td>
				 <td><?php echo $d['bank_phone'];?></td>
               
               
            <td><a href="edit_blood_bank.php?id=<?php echo $d['id'];?>">edit</a></td>
            <td><a href="delete_blood_bank.php?id=<?php echo $d['id'];?>">delete</a></td>
			
            </tr>
			<?php
			}
			
			?>
            
        
        </table>
        
        
		<div class="clear"></div>
	</div>
<div class="clear"></div>
<?php

	include "footer.php";
?>
</div>
</body>
</html>