<?php

	session_start();
	include "db_con.php";
	$msg="";
	$obj=new help();
	
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
		$name=$_REQUEST['name'];
		$email=$_REQUEST['email'];
		$password=$_REQUEST['password'];
		$con_password=$_REQUEST['con_password'];
		$date_of_birth=$_REQUEST['date_of_birth'];
		$gender=$_REQUEST['gender'];
		$blood_group=$_REQUEST['blood_group'];
		$weight=$_REQUEST['weight'];
		$feedback=$_REQUEST['feedback'];
		$residence_phone=$_REQUEST['residence_phone'];
		$mobile=$_REQUEST['mobile'];
		$address=$_REQUEST['address'];
		$city=$_REQUEST['city'];
		
		$sql="insert into register_donor values (NULL,'".$name."','".$email."','".$password."','".$con_password."','".$date_of_birth."','".$gender."','".$blood_group."','".$weight."','".$feedback."','".$residence_phone."','".$mobile."','".$address."','".$city."')";
	
		mysql_query($sql);
		
		$msg="<div style='background:orange;width:200px;height:30px;border:1px solid black;'> Data updated complete.</div>";
		
	}
	

?>

<html>
<head>
<title> My project</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Copyright" content="arirusmanto.com">
<meta name="description" content="Admin MOS Template">
<meta name="keywords" content="Admin Page">
<meta name="author" content="Ari Rusmanto">
<meta name="language" content="Bahasa Indonesia">

<link rel="shortcut icon" href="stylesheet/img/devil-icon.png"> <!--Pemanggilan gambar favicon-->
<link rel="stylesheet" type="text/css" href="mos-css/mos-style.css"> <!--pemanggilan file css-->
</head>

<body>
<?php
	include "header.php";

?>

<div id="wrapper">
	<?php
	
		include "left.php";
	
	?>
	<div id="rightContent">
	<h3>ONLINE_BLOOD_BANK</h3>
	<div class="quoteOfDay">
	<b>Save The Life :</b><br>
	<i style="color: #5b5b5b;">"you really can,Donate your blood"</i>
	</div>
		
		  
		<form name="form1" method="post" action="">
        	<table border="1">
            
                 
			
				<tr>
                <td>name</td>
                <td>:</td>
                <td><input type="text" name="name" id="name" /></td>
                </tr>	
				<tr>
                <td>Email ID</td>
                <td>:</td>
                <td><input type="text" name="email" id="email" /></td>
                </tr>	
				<tr>
                <td>Password</td>
                <td>:</td>
                <td><input type="password" name="password" id="password" /></td>
                </tr>
				<tr>
                <td>Confirm Password</td>
                <td>:</td>
                <td><input type="password" name="con_password" id="con_password" /></td>
                </tr>
				<tr>
                <td>Date Of Birth</td>
                <td>:</td>
                <td><input type="date" name="date_of_birth" id="date_birth" /></td>
            	 </tr>
				 
				 <tr>
                <td>Gender</td>
                <td>:</td>
                <td><input type="text" name="gender" id="gender" /></td>
                </tr>
				
              <tr>
                <td>Blood Group</td>
                <td>:</td>
				<td>
                <ul>
      <li class="list1">
        <select name="blood_group">
          <option>Select</option>
          <option>A+</option>
          <option>B+</option>
          <option>O+</option>
          <option>A-</option>
          <option>B-</option>
          <option>O-</option>
          <option>AB+</option>
          <option>AB-</option>
          <option>A</option>
        </select>
      </li>
	  </td>
                </tr>
              
              
			  <tr>
                <td>Weight</td>
                <td>:</td>
                <td><input type="text" name="weight" id="weight" /></td>
                </tr>
				
				<tr>
                <td>Feedback</td>
                <td>:</td>
				<td>
				<ul>
                <select name="feedback">
              <option>Select</option>
              <option>Yet to Donate</option>
              <option>Regular Donor</option>
              <option>On need Basis</option>
            </select>
			</ul>
			</td>
                </tr>
              
              <tr>
                <td>Residence Phone</td>
                <td>:</td>
                <td><input type="text" name="residence_phone" id="residence_phone" /></td>
                </tr>
              
			  <tr>
                <td>Mobile</td>
                <td>:</td>
                <td><input type="text" name="mobile" id="mobile" /></td>
                </tr>
              
			  <tr>
                <td>Address</td>
                <td>:</td>
                <td><input type="text" name="address" id="address" /></td>
                </tr>
              
			  <tr>
                <td>City</td>
                <td>:</td>
				<td>
				<li class="list2">
        <select name="city">
          <option>Select</option>
		   <option>Mumbai</option>
              <option>Delhi</option>
              <option>Bangalore</option>
              <option>Chennai</option>
              <option>Hyderabad</option>
              <option>Ahmedabad</option>
              <option>Kolkata</option>
              <option>Surat</option>
              <option>Pune</option>
			  <option>Tamluk</option>
			  <option>Contai</option>
			  <option>Holdia</option>
			  <option>Medinipur</option>
              <option>Jaipur</option>
              <option>Lucknow</option>
              <option>Kanpur</option>
              <option>Nagpur</option>
              <option>Visakhapatnam</option>
              <option>Indore</option>
              <option>Thane</option>
              <option>Bhopal</option>
              <option>Madurai</option>
              <option>Patna</option>
              <option>Vadodara</option>
              <option>Ghaziabad</option>
              <option>Ludhiana</option>
              <option>Agra</option>
              <option>Nashik</option>
              <option>Faridabad</option>
              <option>Rajkot</option>
              <option>Meerut</option>
              <option>Aurangabad</option>
              <option>Dhanbad</option>
              <option>Amritsar</option>
              <option>Navi Mumbai</option>
              <option>Allahabad</option>
              <option>Ranchi</option>
              <option>Howrah</option>
              <option>Jabalpur</option>
              <option>Gwalior</option>
              <option>Jodhpur</option>
              <option>Guwahati</option>
              <option>Kota</option>
              <option>Chandigarh</option>
              <option>Thiruvananthapuram</option>
              <option>Solapur</option>
              <option>Noida</option>
              <option>Jamshedpur</option>
              <option>Bhilai</option>
              <option>Firozabad</option>
              <option>Kochi</option>
              <option>Durgapur</option>
              <option>Raniganj</option>
              <option>Asansol</option>
              <option>Burdwan</option> 	
          
        </select>
      </li>
                <td>
                </tr>
              
                <tr>
                <td><center><input type="submit" name="s1" value="Submit"/></center></td>
                <td>:</td>
                <td><input type="reset" name="s2"/></td>
                </tr>
            
            </table>
        
        
	  </form>
      <div><?php echo $msg;?></div>
	  <div class="clear"></div>
      
	</div>
<div class="clear"></div>
<?php

	include "footer.php";
?>
</div>
</body>
</html>