<div id="header">
	<div class="inHeader">
		<div class="mosAdmin">
		Hii,<?php @$user=$_SESSION['user'];echo $user;?><br>
		<a href="logout.php">Log Out</a>
		</div>
	<div class="clear">
	</div>
	</div>
</div>