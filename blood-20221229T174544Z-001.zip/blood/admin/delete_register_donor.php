<?php

	include "db_con.php";
	$obj=new help();
	
	$id=$_REQUEST['id'];
	
	$sql="delete from register_donor where id='".$id."'";
	mysql_query($sql);
	
	header("location:view_register_donor.php");


?>