<?php

	session_start();
	include "db_con.php";
	$obj=new help();
?>

<html>
<head>
<title>Myproject</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Copyright" content="arirusmanto.com">
<meta name="description" content="Admin MOS Template">
<meta name="keywords" content="Admin Page">
<meta name="author" content="Ari Rusmanto">
<meta name="language" content="Bahasa Indonesia">

<link rel="shortcut icon" h1111111111110ref="stylesheet/img/devil-icon.png"> <!--Pemanggilan gambar favicon-->
<link rel="stylesheet" type="text/css" href="mos-css/mos-style.css"> <!--pemanggilan file css-->
</head>

<body>
<?php
	include "header.php";

?>

<div id="wrapper">
	<?php
	
		include "left.php";
	
	?>
	<div id="rightContent">
	<h3>Dashboard</h3>
	<div class="quoteOfDay">
	<b>Quote of the day :</b><br>
	<i style="color: #5b5b5b;">"If you think you can, you really can"</i>
	</div>
		
		  
		<table border="1">
        	<tr>
            	<td>Id</td>
                
                <td>Description</td>
				<td>Image</td>
                
       
                <td>Delete</td>
                
            </tr>
            <?php
			$sql="select * from gallery";
			$rs=mysql_query($sql);
			while($d=mysql_fetch_array($rs))
			{
			?>
            <tr>
            	<td><?php echo $d['id'];?></td>
                
                <td><?php echo $d['description'];?></td>
                 
                  <td><img src="upload/<?php echo $d['file_name'];?>" width="96" height="79"/></td>
               
            
            <td><a href="delete_gallery.php?id=<?php echo $d['id'];?>">Delete</a></td>
		
            </tr>
			<?php
			}
			
			?>
            
        
        </table>
        
        
		<div class="clear"></div>
	</div>
<div class="clear"></div>
<?php

	include "footer.php";
?>
</div>
</body>
</html>

