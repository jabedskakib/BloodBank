<?php

	include "db_con.php";
	$obj=new help();
	
	$id=$_REQUEST['id'];
	
	$sql="delete from blood_master where id='".$id."'";
	mysql_query($sql);
	
	header("location:view_blood_master.php");


?>