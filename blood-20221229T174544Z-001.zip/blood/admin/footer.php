<div id="footer">
	&copy; 2017 TIMT css template | <a href="#">created &</a> | design by <a href="http://arirusmanto.com" rel="nofollow" target="_blank">BCA 3rd year</a><br>
	 <a href="#"></a> 
</div>