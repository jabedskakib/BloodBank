<?php

	session_start();
	include "db_con.php";
	$msg="";
	$obj=new help();
	$id=$_REQUEST['id'];
	
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
	
		
		$name=$_REQUEST['name'];
		$email=$_REQUEST['email'];
		
		$date_of_birth=$_REQUEST['date_of_birth'];
		$gender=$_REQUEST['gender'];
		$blood_group=$_REQUEST['blood_group'];
		$weight=$_REQUEST['weight'];
		$feedback=$_REQUEST['feedback'];
		$residence_phone=$_REQUEST['residence_phone'];
		$mobile=$_REQUEST['mobile'];
		$address=$_REQUEST['address'];
		$city=$_REQUEST['city'];
		
		$sql="update register_donor set name='".$name."', email='".$email."', date_of_birth='".$date_of_birth."', gender='".$gender."', blood_group='".$blood_group."', weight='".$weight."', feedback='".$feedback."', residence_phone='".$residence_phone."', mobile='".$mobile."', address='".$address."', city='".$city."' where id='".$id."'";
		echo $sql;
		mysql_query($sql);
		
		$msg="<div style='background:orange;width:200px;height:30px;border:1px solid black;'>Data updated.</div>";
		
	}
	
	$sql1="select * from register_donor where Id='".$id."'";
	$rs=mysql_query($sql1);
	$d=mysql_fetch_array($rs);
?>

<html>
<head>
<title>Myproject</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Copyright" content="arirusmanto.com">
<meta name="description" content="Admin MOS Template">
<meta name="keywords" content="Admin Page">
<meta name="author" content="Ari Rusmanto">
<meta name="language" content="Bahasa Indonesia">

<link rel="shortcut icon" href="stylesheet/img/devil-icon.png"> <!--Pemanggilan gambar favicon-->
<link rel="stylesheet" type="text/css" href="mos-css/mos-style.css"> <!--pemanggilan file css-->
</head>

<body>
<?php
	include "header.php";

?>

<div id="wrapper">
	<?php
	
		include "left.php";
	
	?>
	<div id="rightContent">
	<h3>ONLINE_BLOOD_BANK</h3>
	<div class="quoteOfDay">
	<b>Save The Life :</b><br>
	<i style="color: #5b5b5b;">"you really can,Donate your blood"</i>
	</div>	
		
	 		 	  
		<form name="form1" method="post" action="">
        	<table border="1">  
				<tr>
                <td>Name</td>
                <td>:</td>
                <td><input type="text" name="name" id="name"  value="<?php echo $d['name'];?>"/></td>
                </tr>	
				<tr>
                <td>Email ID</td>
                <td>:</td>
                <td><input type="text" name="email" id="email" value="<?php echo $d['email'];?>" /></td>
                </tr>	
				
				<tr>
                <td>Date Of Birth</td>
                <td>:</td>
                <td><input type="date" name="date_of_birth" id="date_of_birth" value="<?php echo $d['date_of_birth'];?>" /></td>
                </tr>
				<tr>
                <td>Gender</td>
                <td>:</td>
                <td><input type="text" name="gender" id="gender" value="<?php echo $d['gender'];?>" /></td>
                </tr>
				<tr>
                <td>Blood Group</td>
                <td>:</td>
                <td><input type="text" name="blood_group" id="blood_group" value="<?php echo $d['blood_group'];?>" /></td>
                </tr>
				<tr>
                <td>Weight</td>
                <td>:</td>
                <td><input type="text" name="weight" id="weight" value="<?php echo $d['weight'];?>" /></td>
                </tr>
				<tr>
                <td>Feedback</td>
                <td>:</td>
                <td><input type="text" name="feedback" id="feedback" value="<?php echo $d['feedback'];?>" /></td>
                </tr>
				<tr>
                <td>Residence Phone</td>
                <td>:</td>
                <td><input type="text" name="residence_phone" id="residence_phone" value="<?php echo $d['residence_phone'];?>" /></td>
                </tr>
				<tr>
                <td>Mobile</td>
                <td>:</td>
                <td><input type="text" name="mobile" id="mobile" value="<?php echo $d['mobile'];?>" /></td>
                </tr>
				<tr>
                <td>Address</td>
                <td>:</td>
                <td><input type="text" name="address" id="address" value="<?php echo $d['address'];?>" /></td>
                </tr>
				<tr>
                <td>City</td>
                <td>:</td>
                <td><input type="text" name="city" id="city" value="<?php echo $d['city'];?>" /></td>
                </tr>
                <tr>
                <td><input type="submit" name="s1" value="Submit"/></td>
                <td>:</td>
                <td><input type="reset" name="s2"/></td>
                </tr>
            </table>
        
        
	  </form>
      <div><?php echo $msg;?></div>
	  <div class="clear"></div>
      
	</div>
<div class="clear"></div>
<?php

	include "footer.php";
?>
</div>
</body>
</html>