
<?php

	session_start();
?>

<html>
<head>
<title>Myproject</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Copyright" content="arirusmanto.com">
<meta name="description" content="Admin MOS Template">
<meta name="keywords" content="Admin Page">
<meta name="author" content="Ari Rusmanto">
<meta name="language" content="Bahasa Indonesia"> 

<link rel="shortcut icon" href="stylesheet/img/devil-icon.png"> <!--Pemanggilan gambar favicon-->
<link rel="stylesheet" type="text/css" href="mos-css/mos-style.css"> <!--pemanggilan file css-->
</head>

<body>
<?php
	include "header.php";

?>

<div id="wrapper">
	<?php
	
		include "left.php";
	
	?>
	<div id="rightContent">
	<h3>Dashboard</h3>
	<div class="quoteOfDay">
	<b>Quote of the day :</b><br>
	<i style="color: #5b5b5b;">"If you think you can, you really can"</i>
	</div>
		
		
		<div class="shortcutHome">
		<a href="add_gallery.php"><img src="mos-css/img/bukutamu.png"><br>
		Add Gallery </a>
		
        <a href="view_gallery.php"><img src="mos-css/img/bukutamu.png"><br>
        View Gallery </a>
		</div>
		
		<div class="clear"></div>
	</div>
<div class="clear"></div>
<?php

	include "footer.php";
?>
</div>
</body>
</html>

