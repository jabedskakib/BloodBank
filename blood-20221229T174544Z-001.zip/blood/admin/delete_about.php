
<?php

	include "db_con.php";
	$obj=new help();
	
	$id=$_REQUEST['id'];
	
	$sql="delete from aboutus where id='".$id."'";
	mysql_query($sql);
	
	header("location:view_about.php");


?>