<?php

	session_start();
	include "db_con.php";
	$obj=new help();
?>

<html>
<head>
<title>Myproject</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Copyright" content="arirusmanto.com">
<meta name="description" content="Admin MOS Template">
<meta name="keywords" content="Admin Page">
<meta name="author" content="Ari Rusmanto">
<meta name="language" content="Bahasa Indonesia">

<link rel="shortcut icon" href="stylesheet/img/devil-icon.png"> <!--Pemanggilan gambar favicon-->
<link rel="stylesheet" type="text/css" href="mos-css/mos-style.css"> <!--pemanggilan file css-->
</head>

<body>
<?php
	include "header.php";

?>

<div id="wrapper">
	<?php
	
		include "left.php";
	
	?>
	<div id="rightContent">
	<h3>Dashboard</h3>
	<div class="quoteOfDay">
	<b>Quote of the day :</b><br>
	<i style="color: #5b5b5b;">"If you think you can, you really can"</i>
	</div>
		
		  
		<table border="1">
        	<tr>
            	
                <td>Title</td>
                <td>Description</td>
				<td>Edit</td>
				<td>Delete</td>
				                
            </tr>
            <?php
			$sql="select * from aboutus";
			$rs=mysql_query($sql);
			while($d=mysql_fetch_array($rs))
			{
			?>
            <tr>
            	
                <td><?php echo $d['title'];?></td>
                <td><?php echo $d['details'];?></td>
               
            <td><a href="edit_about.php?id=<?php echo $d['id'];?>">Edit</a></td>
            <td><a href="delete_about.php?id=<?php echo $d['id'];?>">Delete</a></td>
			
            </tr>
			<?php
			}
			
			?>
            
        
        </table>
        
        
		<div class="clear"></div>
	</div>
<div class="clear"></div>
<?php

	include "footer.php";
?>
</div>
</body>
</html>