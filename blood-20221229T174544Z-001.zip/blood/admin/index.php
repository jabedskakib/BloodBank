<?php

	session_start();
	
	include "db_con.php";
	$obj=new help();//object cration...
	$msg="";
	
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
		$user=$_REQUEST['user'];
		
		$password=$_REQUEST['password'];
		
		$sql="select * from login where user='".$user."' and password='".$password."'";
		
		$rs=mysql_query($sql);//execution of queries...
		$n=mysql_num_rows($rs);
		
			if($n>0)
			{
				
				$_SESSION['user']=$user;
				header("location:home.php");
			}
			else
			{
				
				$msg="Invalid login";	
				
			}
			
		
	}

?>

<html>
<head>
<title>Admin MOS Template</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Copyright" content="arirusmanto.com">
<meta name="description" content="Admin MOS Template">
<meta name="keywords" content="Admin Page">
<meta name="author" content="Ari Rusmanto">
<meta name="language" content="Bahasa Indonesia">

<link rel="shortcut icon" href="stylesheet/img/devil-icon.png"> <!--Pemanggilan gambar favicon-->
<link rel="stylesheet" type="text/css" href="mos-css/mos-style.css"> <!--pemanggilan file css-->
</head>

<body>
<div id="header">
	<div class="inHeaderLogin"></div>
</div>

<div id="loginForm">
	<div class="headLoginForm">
	Login Administrator
	</div>
	<div class="fieldLogin">
	<form method="POST" action="">
	<label>Username</label><br>
	
	<label>
	<input type="text" name="user">
	</label>
	<br>
	<label>Password</label>
	<p>
	  <label>
	  <input type="password" name="password">
	  </label>
	  <br>
	  <br>
	  <input type="submit" class="button" value="Login">
	  </p>
	</form>
	</div>
    <div><?php echo $msg;?></div>
</div>
</body>
</html>