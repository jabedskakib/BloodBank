
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Contact Us</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/contact_us.css"/>
<body>
<div class="wrap">
<?php
	require"login_home_header.php";
?>
<?php
	require"contact_us.php";
?>

</div>
<?php
	require"footer.php";
?>
</body>
</html>
