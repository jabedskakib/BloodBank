<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Indian Blood Bank</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/search_result.css"/>
<body>
<div class="wrap">
<div class="main_if">
<h2 class="heading">Search Results</h2>
  <?php
 	include"db_con.php";
	$blood_group=$_REQUEST['blood_group'];
	$city=$_REQUEST['city'];		
	$sql="select * from register_donor where blood_group='".$blood_group."' and city='".$city."'";
	$rs=mysql_query($sql);
	while($d=mysql_fetch_array($rs))
	{ 
		
?>
    				
       <div class="count_result">
       		<p><?php echo $d['name'];?>  IS REGISTER DONOR AND HIS MOBILE NUMBER IS <b><?php echo $d['mobile']; ?></b>, for blood group <b> " <?php echo $blood_group?> "</b>in city <?php echo $city;?></p>
       </div>
               
<?php
}
?> 
  </div>
</div>

  
</body>

</html>
