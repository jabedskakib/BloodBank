
<?php
				
				$con=mysql_connect("localhost","root","");	
				
				mysql_select_db("online_blood_bank",$con);
				
			
			
			
		

?>