<?php
	include "db_con.php";
	//$obj=new help();
?>
<!doctype html>
<html>
<head>
<script type="text/javascript">
function regform()
{
if(frm.name.value==" ")
{
alert("name must be filled out");
frm.name.focus();
return false;
}
}
function regform()
{
if(frm.password.value==" ")
{
alert("Please filled out the password!..");
frm.password.focus();
return false;
}
if(frm.password.value).lenth<5)
{
alert("password must be contant 5 caharecter!...");
frm.password.focus();
return false;
}
if(frm.con_password.value != frm.password.value)
{
alert("password confermation did not match!..");

return false;
}

}

</script>
<meta charset="utf-8">
<title>Registration</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/register1.css"/>
<body>
<div class="wrap">
<?php
	require"header.php";
?>
<div class="main">
	<div class="blank"></div>
    <div class="mainA">
      <h2 class="mainA_heading">Register as a Blood Donor</h2>
      
      <form class="mainA_form" name="frm" method="post" action="reg_code.php" onSubmit="return regform()">
        <fieldset class="fieldset">
          <legend class="form_legend">LOGIN INFORMATION</legend>
          <section class="section1">
            <p class="para1">Full Name *</p>
            <p class="para2">Email ID *</p>
          </section>
          <section class="section2">
            <input class="mainA_input_name" type="text" name="name" id="" required/>
            <input class="mainA_input_email" type="email" name="email" id="" required/>
          </section>
          <section class="section3">
            <p class="para3">Password *</p>
            <p class="para4">Confirm Password *</p>
          </section>
          <section class="section4">
            <input class="mainA_input_password" type="password" name="password" id="" required/>
            <input class="mainA_input_confirm" type="password" name="con_password" id="" required/>
          </section>
        </fieldset>
        <fieldset class="fieldset">
          <legend class="form_legend">DONOR INFORMATION</legend>
          <section class="section1">
            <p class="section1_para1">Date of Birth *</p>
            <p class="para2">Gender *</p>
          </section>
          <section class="section2">
            <input class="mainA_input_name" type="date" name="date_of_birth" id="date_of_birth" required/>
            <p class="para1_gender">Female</p>
            <input class="mainA_input1_gender" type="radio" name="gender" value="female" id="" required/>
            <p class="para2_gender">Male</p>
            <input class="mainA_input2_gender" type="radio" name="gender" value="male" id="" required/>
          </section>
          <section class="section3">
            <p class="para3_select">Your Blood Group *</p>
            <p class="para4">Weight (Kg) *</p>
          </section>
          <section class="section4">
            <select class="mainA_select" name="blood_group" required>
              <option>Select</option>
              <option>A+</option>
              <option>B+</option>
              <option>O+</option>
              <option>A-</option>
              <option>B-</option>
              <option>O-</option>
              <option>AB+</option>
              <option>AB-</option>
              <option>A</option>
            </select>
            <input class="mainA_input_confirm" type="text" name="weight" id=""/>
          </section>
          <section class="section5">
            <p class="para5">How often you donate blood? *</p>
          </section>
          <section class="section6">
            <select class="mainA_select" name="feedback" required>
              <option>Select</option>
              <option>Yet to Donate</option>
              <option>Regular Donor</option>
              <option>On need Basis</option>
            </select>
          </section>
        </fieldset>
        <fieldset class="fieldset3">
          <legend class="form_legend">CONTACT INFORMATION</legend>
          <section class="section1">
            <p class="para1">Residence Phone *</p>
            <p class="para2">Mobile No *</p>
          </section>
          <section class="section2">
            <input class="mainA_input_name" type="text" name="residence_phone" id="" required/>
            <input class="mainA_input_email" type="text" name="mobile" id="" required/>
          </section>
          <section class="section3">
            <p class="para_input_textfield">Address *</p>
          </section>
          <section class="section4">
            <input class="mainA_input_textfield" type="text" name="address" id="" required/>
          </section>
          <section class="section5">
            <p class="para5">City *</p>
          </section>
          <section class="section6">
            <select class="mainA_select" name="city" required>
              <option>Select City</option>
              <option>Mumbai</option>
              <option>Delhi</option>
              <option>Bangalore</option>
              <option>Chennai</option>
              <option>Hyderabad</option>
              <option>Ahmedabad</option>
              <option>Kolkata</option>
              <option>Surat</option>
              <option>Pune</option>
			  <option>Tamluk</option>
			  <option>Contai</option>
			  <option>Holdia</option>
			  <option>Medinipur</option>
              <option>Jaipur</option>
              <option>Lucknow</option>
              <option>Kanpur</option>
              <option>Nagpur</option>
              <option>Visakhapatnam</option>
              <option>Indore</option>
              <option>Thane</option>
              <option>Bhopal</option>
              <option>Madurai</option>
              <option>Patna</option>
              <option>Vadodara</option>
              <option>Ghaziabad</option>
              <option>Ludhiana</option>
              <option>Agra</option>
              <option>Nashik</option>
              <option>Faridabad</option>
              <option>Rajkot</option>
              <option>Meerut</option>
              <option>Aurangabad</option>
              <option>Dhanbad</option>
              <option>Amritsar</option>
              <option>Navi Mumbai</option>
              <option>Allahabad</option>
              <option>Ranchi</option>
              <option>Howrah</option>
              <option>Jabalpur</option>
              <option>Gwalior</option>
              <option>Jodhpur</option>
              <option>Guwahati</option>
              <option>Kota</option>
              <option>Chandigarh</option>
              <option>Thiruvananthapuram</option>
              <option>Solapur</option>
              <option>Noida</option>
              <option>Jamshedpur</option>
              <option>Bhilai</option>
              <option>Firozabad</option>
              <option>Kochi</option>
              <option>Durgapur</option>
              <option>Raniganj</option>
              <option>Asansol</option>
              <option>Burdwan</option>
            </select>
            
            
          </section>
        </fieldset>
        <div class="captcha">
        <p style="color:red; text-align:center; line-height:75px;">
      	<?php
				echo @$_GET['msg1'];
		?>
        </p></div>
        <div class="checkbox1">
          <input class="input_checkbox" type="checkbox" name="eligibility" id="" value=" I confirm that I am eligible " required/>
          <p class="para_checkbox">I have read the <a href="#">Eligibility Criteria</a> and confirm that I am eligible to donate blood.</p>
        </div>
        <div class="checkbox2">
          <input class="input_checkbox" type="checkbox" name="conditions" id="" value=" I agree to the terms & conditions" required/>
          <p class="para_checkbox">I agree to the <a href="#">Terms and Conditions</a> and consent to have my contact and donor information published to the potential blood recipients.</p>
        </div>
        <section class="submit">
          <input class="register" type="submit" name="submit" value="Register"/>
        </section>
      </form>
      </p>
    </div>
    <div class="mainB"><a href="index_register.php"></a></div>
    
  </div>
</div>
<?php
  require"footer.php";
?>

</body>
</html>
