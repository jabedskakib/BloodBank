<div class="wrap">
  <div class="main">
    <h2 class="main_heading" >Blood Tips</h2>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">Beat the myth</h3>
      </div>
      <div class="para">
        <p class="main_para1">Donating blood is safe and simple. It takes approximately 10-15 minutes to complete the blood donation process. Any healthy adult between 18 years and 60 years of age can donate blood. This is what you can expect when you are ready to donate blood:</p>
        <ul>
          <li>
            <p class="main_para">You walk into a reputed and safe blood donation centre or a mobile camp organized by a reputed institution.</p>
          </li>
          <li>
            <p class="main_para">A few questions will be asked to determine your health status (general questions on health, donation history etc). Usually you will be asked to fill out a short form.</p>
          </li>
          <li>
            <p class="main_para">Then a quick physical check will be done to check temperature, blood pressure, pulse and hemoglobin content in blood to ensure you are a healthy donor.</p>
          </li>
          <li>
            <p class="main_para">If found fit to donate, then you will be asked to lie down on a resting chair or a bed. Your arm will be thoroughly cleaned. Then using sterile equipments blood will be collected in a special plastic bag. Approximately 350 ml of blood will be collected in one donation. Those who weigh more than 60 Kg can donate 450 ml of blood.</p>
          </li>
          <li>
            <p class="main_para">Then you must rest and relax for a few minutes with a light snack and something refreshing to drink. Some snacks and juice will be provided.</p>
          </li>
          <li>
            <p class="main_para">Blood will be separated into components within eight hours of donation.</p>
          </li>
          <li>
            <p class="main_para">The blood will then be taken to the laboratory for testing.</p>
          </li>
          <li>
            <p class="main_para">Once found safe, it will be kept in special storage and released when required.</p>
          </li>
          <li>
            <p class="main_para">The blood is now ready to be taken to the hospital, to save lives.</p>
          </li>
        </ul>
      </div>
    </div>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">Blood Groups</h3>
      </div>
      <div class="para">
        <p class="main_para1">Blood type is determined by which antibodies and antigens the person's blood produces. An individual has two types of blood groups namely ABO-grouping and Rh-grouping. Rh is called as the Rhesus factor that has come to us from Rhesus monkeys.</p>
        <p class="main_para1" style="margin-top:15px;">Most humans are in the ABO blood group. The ABO group has four categories namely</p>
        <ul style="list-style:decimal; margin-top:8px;">
          <li>
            <p class="main_para">A group</p>
          </li>
          <li>
            <p class="main_para">B group</p>
          </li>
          <li>
            <p class="main_para">O group</p>
          </li>
          <li>
            <p class="main_para">AB group</p>
          </li>
        </ul>
        <p class="main_para" style="margin-left:15px;">First two groups, either the individual is said to be Negative or  Positive blood group.</p>
        <p class="main_para1" style="margin-top:15px;">Thus blood group of any human being will mainly fall in any one of the following groups</p>
        <ul style="margin-top:8px;">
          <li>
            <p class="main_para">A positive or A negative</p>
          </li>
          <li>
            <p class="main_para">B positive or B negative</p>
          </li>
          <li>
            <p class="main_para">O positive or O negative</p>
          </li>
          <li>
            <p class="main_para">AB positive or AB negative.</p>
          </li>
        </ul>
      </div>
    </div>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">Universal Donors and Recipients</h3>
      </div>
      <div class="para">
        <p class="main_para1">The most common blood type is O, followed by type A.</p>
        <p class="main_para" style="margin-top:15px; margin-left:15px; margin-right:20px;">Type O individuals are often called "universal donors" since their blood can be transfused into persons with any blood type. Those with type AB blood are called "universal recipients" because they can receive blood of any type.</p>
        <p class="main_para" style="margin-top:15px; margin-left:15px;  margin-right:20px;">However, since approximately twice as many people in the general population have O and A blood types, a blood bank's need for this type of blood increases exponentially.</p>
      </div>
    </div>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">DO donate blood, only if you satisfy all of the following conditions</h3>
      </div>
      <div class="para">
        <p class="main_para1">We highly recommend you to donate your blood only after examined your health by a doctor to check whether the given conditions are satisfy your health or not. If any one of the given conditon does not satisfy or match with your health, please do not donate your blood.</p>
        <ul style="list-style:decimal;">
          <li>
            <p class="main_para">You are between age group of 18-60 years.</p>
          </li>
          <li>
            <p class="main_para">Your weight is 45 kgs or more.</p>
          </li>
          <li>
            <p class="main_para">Your hemoglobin is 12.5 gm% minimum.</p>
          </li>
          <li>
            <p class="main_para">Your last blood donation was 3 or more months earlier.</p>
          </li>
          <li>
            <p class="main_para">Then you must rest and relax for a few minutes with a light snack and something refreshing to drink. Some snacks and juice will be provided.</p>
          </li>
          <li>
            <p class="main_para">You are healthy and have not suffered from malaria, typhoid or other transmissible disease in the recent past.</p>
          </li>
        </ul>
      </div>
    </div>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">DO NOT donate blood, if you have any of the following conditions</h3>
      </div>
      <div class="para">
        <p class="main_para1">We highly recommend you to read the conditions carefully. If any one of the given conditon does not satisfy or match with your health, please do not donate your blood until you satisfy all the conditions.</p>
        <ul style="list-style:decimal;">
          <li>
            <p class="main_para">Cold or fever in the past 1 week.</p>
          </li>
          <li>
            <p class="main_para">Under treatment with antibiotics or any other medication.</p>
          </li>
          <li>
            <p class="main_para">Cardiac problems, hypertension, epilepsy, diabetes (on insulin therapy), history of cancer, chronic kidney or liver disease, bleeding tendencies, venereal disease etc.</p>
          </li>
          <li>
            <p class="main_para">Major surgery in the last 6 months.</p>
          </li>
          <li>
            <p class="main_para">Vaccination in the last 24 hours.</p>
          </li>
          <li>
            <p class="main_para">Had a miscarriage in the last 6 months or have been pregnant / lactating in the last one year.</p>
          </li>
          <li>
            <p class="main_para">Had fainting attacks during last donation.</p>
          </li>
          <li>
            <p class="main_para">Have regularly received treatment with blood products.</p>
          </li>
          <li>
            <p class="main_para">Shared a needle to inject drugs/ have history of drug addiction.</p>
          </li>
          <li>
            <p class="main_para">Had sexual relations with different partners or with a high risk individual.</p>
          </li>
          <li>
            <p class="main_para">Been tested positive for antibodies to HIV.</p>
          </li>
        </ul>
      </div>
    </div>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">What makes a Healthy Donor</h3>
      </div>
      <div class="para">
        <p class="main_para1">A healthy diet helps ensure a successful blood donation, and also makes you feel better! Check out the following recommended foods to eat prior to your donation.</p>
        <ul style="list-style:decimal;">
          <li>
            <p class="main_para">Low fat foods.</p>
          </li>
          <li>
            <p class="main_para">Iron rich foods.</p>
          </li>
        </ul>
      </div>
    </div>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">Before donating the Blood</h3>
      </div>
      <div class="para">
        <p class="main_para1">We request you to follow the given suggestions to become a healthy donor.Please maintain the healthy routine.</p>
        <p class="main_para1" style="margin-top:15px;"><strong>NOTICE :</strong>All equipment is sterile; needles are used only once and then discarded. In the great majority of individuals, a donation of 450 ml is less than 10% of your total body volume and may be given safely every 3 months. Your body keeps on discarding and replenishing blood all the time whether you give blood or not, so this amount is quickly replenished.</p>
        <ul>
          <li>
            <p class="main_para">Eat something substantial before your appointment.</p>
          </li>
          <li>
            <p class="main_para">Have plenty of liquid the day before donation, especially in warm weather. In the 3 hours before donating, have at least 3 to 4 good-sized glasses of water or juice.</p>
          </li>
          <li>
            <p class="main_para">Cardiac problems, hypertension, epilepsy, diabetes (on insulin therapy), history of cancer, chronic kidney or liver disease, bleeding tendencies, venereal disease etc.</p>
          </li>
          <li>
            <p class="main_para">You will be asked by the volunteer or staff of the blood donating camp ( where you are going to donate your blood ) to fill a form with brief information on contact details and medical history.</p>
          </li>
          <li>
            <p class="main_para">You will be examined by a doctor to answer some questions about your health history. Your blood pressure and hemoglobin level will be checked.</p>
          </li>
          <li>
            <p class="main_para">An area on your arm will cleanse and insert a brand new sterile needle for the blood draw. This feels like a quick pinch and is over in seconds.</p>
          </li>
          <li>
            <p class="main_para">The actual donation takes about 8-10 minutes, during which you will be seated comfortably.</p>
          </li>
          <li>
            <p class="main_para">When a unit of blood (350 – 450 ml) has been collected, the donation is complete.</p>
          </li>
          <li>
            <p class="main_para">A staff person will place a bandage on your arm.</p>
          </li>
        </ul>
      </div>
    </div>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">After Donation</h3>
      </div>
      <div class="para">
        <p class="main_para1">We highly recommend you to take something to eat and drink in and relax for about 15-20 minutes before departing. Within 24-48 hours your blood volume is completely restored. Apart from enjoying our refreshments and souvenir, other things to help you recover quickly include</p>
        <ul>
          <li>
            <p class="main_para">Drink plenty of water, fruit juice etc. and avoid alcohol for 8 hours after you’ve given blood.</p>
          </li>
          <li>
            <p class="main_para">Avoid any strenuous activity or heavy lifting with the ‘donating arm’ for 24 hours after you’ve given blood.</p>
          </li>
          <li>
            <p class="main_para">If you become unwell in any way after giving blood, speak to the doctor in-charge straight away.</p>
          </li>
        </ul>
      </div>
    </div>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">Blood Bank</h3>
      </div>
      <div class="para">
        <p class="main_para1">A blood bank is a place designed especially for the storage of blood and blood products. Large coolers hold these products at a constant temperature and they are available at a moment's notice.</p>
      </div>
    </div>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">About Blood Donation</h3>
      </div>
      <div class="para">
        <p class="main_para1">Donating blood is a life saving measure especially when you have a rare blood type. Blood donation is safe and simple. It takes only about 10 minutes to donate blood - less than the time of an average telephone call. We can save upto 3 to 4 precious lives by donating blood.</p>
      </div>
    </div>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">World Blood Donor Day</h3>
      </div>
      <div class="para">
        <p class="main_para1">The day is celebrated to raise awareness globally about the need for regular and voluntary blood donation.</p>
      </div>
    </div>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">Our Humble Request</h3>
      </div>
      <div class="para">
        <p class="main_para1">We on behalf of all the people who has deficiency of blood or are suferring from any kind of deceases due to the defiency of blood want to humble request that please don't forget to donate again and again and try to spread it all over the world. We highly recommend to read the given request carefully and please don't forget to go through it.</p>
        <ul>
          <li>
            <p class="main_para">Whole blood donors can give blood again after 3 months.</p>
          </li>
          <li>
            <p class="main_para">Apheresis plasma or platelet donors can give blood in around 2-3 weeks time.</p>
          </li>
          <li>
            <p class="main_para">Tell your friends, colleagues and family about the wonderful feeling you experience on donating blood and saving lives. 
              Enjoy the feeling of knowing that you helped save precious lives!</p>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>
