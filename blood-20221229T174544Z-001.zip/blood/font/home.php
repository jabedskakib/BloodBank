<?php

	
	include "db_con.php";
	//$obj=new help();
?>

<div id="mainA">
        <div id="heading"></div>
     <div id="para_about_heading" align="center">
	 <?php
			$sql="select * from home";
			$rs=mysql_query($sql);
			while($d=mysql_fetch_array($rs))
			{
			?>
	  <h1><?php echo $d['title'];?></h1>
     <p><?php echo $d['details'];?></p>
	 <?php
	 }
	 ?>
    </div>
    <div id="image_slider" align="center">
    	<div id="outerbox">
            <div id="sliderbox">
                <img src="slider_images/1.jpg" width="1001" height="295"/>
                <img src="slider_images/2.jpg" width="1001" height="295"/>
				<img src="slider_images/3.png" width="1001" height="295"/>
				<img src="slider_images/4.png" width="1001" height="295"/>
                <img src="slider_images/5.jpg" width="1001" height="295"/>
				<img src="slider_images/6.jpg" width="1001" height="295"/>
				<img src="slider_images/7.jpg" width="1001" height="295"/>
                <img src="slider_images/8.jpg" width="1001" height="295"/>
          <img src="slider_images/9.jpg" width="1001" height="295"/></div>
       </div>
    </div>
<div id="para_about_heading">
    <p>Blood is universally recognized as the most precious element that sustains life. It saves innumerable lives across the world in a variety of conditions. The need for blood is great - on any given day, approximately 39,000 units of Red Blood Cells are needed. More than 29 million units of blood components are transfused every year. Donate Blood Despite the increase in the number of donors, blood remains in short supply during emergencies, mainly attributed to the lack of information and accessibility. We positively believe this tool can overcome most of these challenges by effectively connecting the blood donors with the blood recipients.</p>
  </div>
    <div id="blank">
    </div>
</div>
