<div class="main">
    <div class="mainA">
      <h2 class="mainA_heading">Contact Us</h2>
  
      <form class="mainA_form" method="post" action="contact_us_code.php">
        <fieldset class="fieldset">
          <legend class="form_legend">FILL-UP FOR CONTACT</legend>
          <section class="section1">
            <p class="para_full_name">Full  Name *</p>
            <p class="para_querry_subject">Query Subject *</p>
          </section>
          <section class="section2">
            <section class="inside_section2">
              <section class="inside_section2A">
                <select class="select_query_subject" name="query_subject">
                  <option>Select</option>
                  <option>Helpline</option>
                  <option>Media/Marketing</option>
                  <option>Other</option>
                </select>
                <section class="para_message">Message *</section>
                <input class="input_message" type="text" name="message" id=""/>
                <section class="section_captcha1">
                  <p style="color:red; text-align:center; line-height:75px;">
                    <?php
				echo @$_GET['msg'];
			?>
                  </p>
                </section>
              </section>
              <section class="inside_section2B">
                <input class="input_full_name" type="text" name="full_name" id=""/>
                <section class="para_email_ID">Email ID *</section>
                <input class="input_email" type="email" name="email" id=""/>
                <section class="para_mobile_number">Mobile Number  *</section>
                <input class="input_mobile_number" type="text" name="mobile_no" id=""/>
                <section class="section_para_city">
                  <p class="para_city">City *</p>
                </section>
                <select class="select_city" name="city">
                  <option>Select</option>
                  <option>Mumbai</option>
                  <option>Delhi</option>
                  <option>Bangalore</option>
                  <option>Chennai</option>
                  <option>Hyderabad</option>
                  <option>Ahmedabad</option>
                  <option>Kolkata</option>
                  <option>Surat</option>
                  <option>Pune</option>
                  <option>Jaipur</option>
                  <option>Lucknow</option>
                  <option>Kanpur</option>
                  <option>Nagpur</option>
                  <option>Visakhapatnam</option>
                  <option>Indore</option>
                  <option>Thane</option>
                  <option>Bhopal</option>
                  <option>Madurai</option>
                  <option>Patna</option>
                  <option>Vadodara</option>
                  <option>Ghaziabad</option>
                  <option>Ludhiana</option>
                  <option>Agra</option>
                  <option>Nashik</option>
                  <option>Faridabad</option>
                  <option>Rajkot</option>
                  <option>Meerut</option>
                  <option>Aurangabad</option>
                  <option>Dhanbad</option>
                  <option>Amritsar</option>
                  <option>Navi Mumbai</option>
                  <option>Allahabad</option>
                  <option>Ranchi</option>
                  <option>Howrah</option>
                  <option>Jabalpur</option>
                  <option>Gwalior</option>
                  <option>Jodhpur</option>
                  <option>Guwahati</option>
                  <option>Kota</option>
                  <option>Chandigarh</option>
                  <option>Thiruvananthapuram</option>
                  <option>Solapur</option>
                  <option>Noida</option>
                  <option>Jamshedpur</option>
                  <option>Bhilai</option>
                  <option>Firozabad</option>
                  <option>Kochi</option>
                  <option>Durgapur</option>
                  <option>Raniganj</option>
                  <option>Asansol</option>
                  <option>Burdwan</option>
                </select>
              </section>
            </section>
          </section>
        </fieldset>
        <input class="send" type="submit" name="submit" value="Send"/>
      </form>
      <div class="submit"> <a href="register.php">
        <div class="donate" type="submit" name="">
          <p>Donate</p>
        </div>
        </a> </div>
      <div style="background:#EBEBEB; width:1000px; height:300px; margin-left:155px; margin-top:50px; padding:20px;border:1px solid #CCCCCC;; border-radius:0px 0px 5px 5px ; float:left;">
        <?php

	$sql="select * from contact_us_home";
	$rs=mysql_query($sql);
	while($d=mysql_fetch_array($rs))
	{
?>
        <h3><?php echo $d['title'];?></h3>
        <div style="width:100%; height:10px;"></div>
        <p><?php echo $d['details'];?> </p>
        <?php
	}
	
	
	?>
      </div>
    </div>
    <div class="mainB"> </div>
  </div>
