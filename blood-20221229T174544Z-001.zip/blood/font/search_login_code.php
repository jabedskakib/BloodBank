<?php

	session_start();
	
	include "Admin/help.php";
	$obj=new help();
	$msg="";
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
			$user=$_REQUEST['email'];
			$pass=$_REQUEST['password'];
			
			$sql="select * from registration where email='".$user."' and password='".$pass."'";
			$rs=mysql_query($sql);
			$n=mysql_num_rows($rs);
			if($n>0)
			{
				
				$_SESSION['user']=$_REQUEST['user'];
				header("location:subject.php");	
			}
			else
			{
				header("location:exam_login.php?msg=Invalid user name or password...");	
			}
		
	}

?>

   