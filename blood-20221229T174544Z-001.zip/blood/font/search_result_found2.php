<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="stylesheet/table_donor_details.css"/>
</head>

<body>
<div class="result_if">
      <div class="_blood_name">
        <div class="blood_group"><?php echo $blood_group?></div>
        <div class="name"><?php echo $name ?> </div>
      </div>
      <div class="loaction">
        <p class="p_area">Aria</p>
      </div>
      <div class="line">
        <p>..................................................................................................................................................................................................................................................................................................................................................................................................................................................................</p>
      </div>
      <div class="date">
        <p class="p_date">Last blood donated date : Yet to donate</p>
      </div>
      <div class="details"> <a href="send_email.php">
        <div class="mail">
          <p><span><img src="images/message.png"/></span>Send Mail</p>
        </div>
        </a> <a href="donor_details.php?msg2=<?php  echo $d['id'] ?>">
        <div class="view_details"> <span><img src="images/view.png"/></span>View Contact Details </div>
        </a> </div>
    </div>
</body>
</html>