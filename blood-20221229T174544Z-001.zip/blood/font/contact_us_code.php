 <?php


	include "connection.php";
	$obj=new help(); 

?>
    <?php
	  	
		if($_SERVER['REQUEST_METHOD']=="POST")
		{
		$query_subject=$_POST['query_subject'];
		$message=$_POST['message'];
		$full_name=$_POST['full_name'];
		$email=$_POST['email'];
		$mobile_no=$_POST['mobile_no'];
		$city=$_POST['city'];
		
		
		if(empty($query_subject))
		{
			header("location:contact_us.php?msg=Please select your query subject");
		}
		else if(empty($message))
		{
			header("location:contact_us.php?msg=Please give the message");
		}
		else if(empty($full_name))
		{
			header("location:contact_us.php?msg=Please enter your full name");
		}
		else if(empty($email))
		{
			header("location:contact_us.php?msg=Please enter your email address");
		}
		else if(empty($mobile_no))
		{
			header("location:contact_us.php?msg=Please enter a valid mobile number");
		}
		else if(empty($city))
		{
			header("location:contact_us.php?msg=Please choose your city ");
		} 
		else{
		$sql="insert into contact_us values('NULL','".$query_subject."','".$message."','".$full_name."','".$email."','".$mobile_no."','".$city."')";
			//echo $sql;exit;
		mysql_query($sql);
		
	}
	header("location:main_contact_us.php?msg=Thank you to cantact us.");
	}
	
	  ?>