 <?php

	$sql="select * from home";
	$rs=mysql_query($sql);
	while($d=mysql_fetch_array($rs))
	{
?>
  <h3><?php echo $d['title'];?></h3>
  <div style="width:100%; height:10px;"></div>
  <p><?php echo $d['details'];?> </p>
  <?php
	}
	
	
	?>