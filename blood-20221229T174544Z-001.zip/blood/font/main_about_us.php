<?php

	
	include "db_con.php";
	//$obj=new help();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>About Us</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/about_us1.css"/>
<body>
<div class="wrap">
<?php
	require"header.php"; 
?>
  <div class="main">
    <h2 class="main_heading" >About Us</h2>
    <div class="heading_border">
      <div class="div_sub_heading">
        <h3 class="sub_heading">Why Save Life Blood Bank ?</h3>
      </div>
      <div class="para">
  <?php
			$sql="select * from aboutus";
			$rs=mysql_query($sql);
			while($d=mysql_fetch_array($rs))
			{
			?>

<p class="main_para1"><b style="color:#C00;"><?php echo $d['title'];?> </b><?php echo $d['details'];?></p>
<?php
	}
	?>
        
      </div>
    </div>
  </div>
</div>


<?php 
	require"footer.php";
?>
</body>
</html>
