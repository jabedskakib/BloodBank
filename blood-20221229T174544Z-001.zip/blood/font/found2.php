<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Indian Blood Bank</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/search_result.css"/>
<body>
<div class="main_if">
<h2 class="heading">Search Results</h2>
  <?php
 	include"connection.php";
	$obj=new help;
	$blood_group=$_REQUEST['blood_group'];
	$city=$_REQUEST['city'];
				
				
	$query="select * from registeration where blood_group='".$blood_group."'";
	$run=mysql_query($query);
	//echo $query;exit();
?>

<?php
	$count=0;
	if($d=mysql_fetch_array($run)>0)
	{ 
		$count=$count+1;
		//echo $query;exit();
?>
    				
       <div class="count_result">
       		<p><?php echo $count ?>results showing in <b><?php echo $city ?></b>, for blood group <b> " <?php echo $blood_group?> "</b></p>
       </div>
               
<?php 
	while($d=mysql_fetch_array($run))
	{ 
		$count=$count+1;
		$name=$d['name'];
		$city=$d['city'];

	require"search_result_found2.php";
	}
}
else
{
		require"search_result_not_found.php";
}
?>  
  </div>


  
</body>

</html>
