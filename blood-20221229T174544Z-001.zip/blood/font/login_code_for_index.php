<?php

	session_start();
	include "connection.php";
	$obj=new help();
	$msg="";
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
			$user=$_REQUEST['user'];
			$pass=$_REQUEST['password'];
			
			$sql="select * from registeration where email='".$user."' and pwd='".$pass."'";
			$rs=mysql_query($sql);
			//echo $rs;exit;
			$n=mysql_num_rows($rs);
			if($n>0)
			{
				
				header("location:donor_details.php");	
			}
			else
			{
				header("location:login_for_donor_details.php?msg=Invalid user name or password...");
			}
		
	}

?>