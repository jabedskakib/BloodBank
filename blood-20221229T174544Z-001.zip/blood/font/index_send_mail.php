<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Send | Mail</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/send_mail.css"/>
<body>
	<div class="wrap"> 
    <?php
	require"header.php";
	?>
    <?php
	require"send_mail.php";
	?>
    <?php
	require"footer.php";
	?>
    </div>
</body>
</html>