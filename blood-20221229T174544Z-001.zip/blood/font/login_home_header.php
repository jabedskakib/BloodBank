<?php
session_start();
$name=$_SESSION['name'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login Home</title>
<link type="text/css" rel="stylesheet" href="stylesheet/header.css"/>
</head>

<body>
<header class="header">
  <div class="header1">
    <div class="header1A"> </div>
    <div class="header1B">
      <div class="header1B1"><img src="images/bbi-logo.png"/></div>
      <div class="header1B2"> </div>
      <div class="header1B3">
        <div class="header1B3A">
          <div class="header1B3A1">

          </div>
          <div class="header1B3A2">
            </div>
        </div>
        <div class="header1B3B">
          <div class="header1B3B1">
         
              </div>
          <div class="header1B3B2">
        	
          </div>
          <a href="#"><div class="header1B3B3">
               <P>Welcome, <?php echo $name;?></P>
            <div>
    </div>

          </div></a>
          <div class="header1B3B4">
            <p class="para_1B3B4">|</p>
          </div>
          <div class="header1B3B4">
            <a href="logout.php" class="a_link1B3B5"><div class="header1B3B5">
              <p>Logout</p>
            </div>
            </a>
          </div>
        </div>
        <div class="header1B3C">
          <div class="header1B3C1">
          </div>
        </div>
      </div>
    </div>
    <div class="header1C"> </div>
  </div>
  <div class="header2">
    <div class="header2A">
      <div class="header2A1"> </div>
      <div class="header2A2"> </div>
    </div>
    <div class="menubar">
      <ul>
       <a href="login_home_home.php"> <li>HOME</li></a>
        <a href="login_home_about_us.php"><li>ABOUT US</li></a>
        <a href="login_home_register.php"><li>REGISTER AS DONOR</li></a>
        <a href="login_home_search.php"> <li>SEARCH DONORS</li></a>
       <a href="login_home_request_blood.php"><li>REQUEST BLOOD</li></a>
        <a href="login_home_blood_tips.php"><li>BLOOD TIPS</li></a>
       <a href="login_home_contact_us.php"> <li>CONTACT US<li></a>
      </ul>
    </div>
    <div class="header2C">
      <div class="header2C1"> </div>
      <div class="header2C2"> </div>
    </div>
  </div>
</header>
</body>
</html>