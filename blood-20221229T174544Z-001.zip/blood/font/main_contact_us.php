<?php

	
	include "db_con.php";
	//$obj=new help();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Request Blood</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/contact_us2.css"/>
<body>
<div class="wrap">
<?php
	require"header.php";
?>

<div class="main">
	<div class="blank"></div>
    <div class="mainA">
      <h2 class="mainA_heading">Contact Us</h2>
	  <?php
	  
	  $sql="select * from contact";
	  $rs=mysql_query($sql);
	  while($d=mysql_fetch_array($rs))
	  {
	  ?>
	  
	  <div style="background:#cccccc; width:300px; border:1px solid green; margin-left:10px; padding-top:3px; margin-top:10px; float:left; height:150px; border-radius:10px 10px 10px 10px;">
	  
	<table width="160" border="0">
	  	<tr>
			<td width="88"><div align="right">Name</div></td>
			<td width="20"><div align="center"><strong>:</strong></div></td>
			<td width="38"><?php echo $d['name'];?></td>
		</tr>
	  
	  
	  	<tr>
			<td><div align="right">Address</div></td>
			<td><div align="center"><strong>:</strong></div></td>
			<td><?php echo $d['add'];?></td>
		</tr>
		<tr>
			<td><div align="right">Phone</div></td>
			<td><div align="center"><strong>:</strong></div></td>
			<td><?php echo $d['phone'];?></td>
		</tr>
		<tr>
			<td><div align="right">Email</div></td>
			<td><div align="center"><strong>:</strong></div></td>
			<td><?php echo $d['email'];?></td>
		</tr>
	  	
	</table>
	</div>
	<?php
		}
		
		?>
	  
    </div>

  
      
  </div>
	 
</div>
</div>
<?php
  	require"footer.php";
  ?>
</body>
 
</html>
