<?php
	include"SendingMail/classes/class.phpmailer.php";   //include the class name where two classes were pasted.
	$mail=new PHPMailer(); // create a new object.
	$mail->isSMTP(); //enable SMTP.
	$mail->SMTPDebug=1; // 1 = errors and messages, 2 = messages only
	$mail->SMTPAuth=true;  //Authentication enable.
	$mail->SMTPSecure='ssl';  //secure transfer enabled.
	$mail->Host="smtp.gmail.com";
	$mail->Port=465; // or 587 it is bydefault.
	$mail->isHTML(false);
	$mail->Username="indianbloodnbank7@gmail.com"; //gmail account name.
	$mail->Password="Administrati0n";  //password of that gmail account.
	$mail->setFrom("indianbloodnbank7@gmail.com","ajay"); 
	$mail->Subject=$_REQUEST['subject'];
	$mail->Body=$_REQUEST['message'];
	$mail->AddAddress=($_REQUEST['to']);
	if(!$mail->send())
	{
		 echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
	}
	else
	{
		echo "Message has been sent.";
	}
?>
