<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="stylesheet/footer.css"/>
</head>

<body>
<div class="footer">
    <ul>
        <li><a href="#">Search Donors</a></li>
        <li>-</li>
        <li><a href="#">About Us</a></li>
        <li>-</li>
        <li><a href="#">Register As Donor</a></li>
        <li>-</li>
        <li><a href="#">Request Blood</a></li>
        <li>-</li>
        <li><a href="#">Blood Tips</a></li>
        <li>-</li>
        <li><a href="#">Privacy Policy</a></li>
		<li><b><a href="#">SaveLifeBloodBankIndia.co.in</a></b> 						student Project from <b><a href="#">student of timt BCA 3rd YEAR</a></b> All rights reserved © 2017</li>
    </ul>
    <ol>
    <li><img src="images/fb-footer.png"/></li>
    </ol>
</div>
</body>
</html>