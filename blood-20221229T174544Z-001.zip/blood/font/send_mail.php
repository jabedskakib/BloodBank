
<div class="main">
      <h2 class="main_heading" align="center">Please fill-up the request details.</h2>
  
      <form class="main_form" method="post" action="send_mail_code.php?$msg4=<?php echo $_GET['msg3'] ?>">
        <fieldset class="fieldset">
          <legend class="form_legend">Login-Info</legend>
          
          <section class="section_main">
              <section class="section_right">
                <label class="para">Your Email-ID *</label>
                <input class="input_email" type="email" name="email" id=""/>
               <section class="section_captcha1">
                  <p style="color:red; text-align:center; line-height:75px;">
                    <?php
				echo @$_GET['msg'];
			?>
                  </p>
                </section>
              </section>
              <section class="section_left">
              <label class="para">Your Name *</label>
                <input class="input_full_name" type="text" name="name" id=""/>
              <label class="para">Message *</label>
                <textarea name="message" cols="41" rows="5"></textarea>
              </section>
              <section class="bottom">
              <input class="submit" type="button" value="Submit"/>
              </section>
          </section>
        </fieldset>
      </form>
    </div>

