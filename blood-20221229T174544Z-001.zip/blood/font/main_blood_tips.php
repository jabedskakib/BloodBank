<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Blood Tips</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/blood_tips.css"/>
<body>
<?php
  	require"header.php";
  ?>
<?php
	require"blood_tips.php";
  ?>
<?php
  require"footer.php";
  ?>
</body>
</html>
