<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Result Found</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/found.css"/>
<body>
<div class="wrap">
<?php
	require"login_home_header.php";
?>
<?php
	include"found2.php";
?>

</body>
</html>
