<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Indian Blood Bank</title>
</head>
<link type="text/css" rel="stylesheet" href="stylesheet/index.css"/>
<body>
<div class="wrap">
<?php
	require"header.php";
?>

<?php
	require"home.php";
?>

</div>
<?php
	require"footer.php";
?>
</body>
</html>
