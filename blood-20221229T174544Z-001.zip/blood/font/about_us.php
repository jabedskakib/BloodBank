<?php

	
	include "db_con.php";
	//$obj=new help();
?>

<div class="main">
	
<div class="mainA">
<?php
			$sql="select * from aboutus";
			$rs=mysql_query($sql);
			while($d=mysql_fetch_array($rs))
			{
			?>

<p class="mainA_para"><b style="color:#C00;"><?php echo $d['title'];?> </b><?php echo $d['description'];?></p>
<?php
	}
	?>
</div>

</div>

</div>
