
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Request Blood</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/request_blood14.css"/>
<body>
<div class="wrap">
<?php
	require"header.php";
?>

<div class="main">
	<div class="blank"></div>
    <div class="mainA">
      <h2 class="mainA_heading">Request Blood</h2>
      
      <form class="mainA_form" method="post" action="request_blood_code.php">
        <fieldset class="fieldset">
          <legend class="form_legend">LOGIN INFORMATION</legend>
          <section class="section1">
            <p class="para_p_name">Patient Name *</p>
            <p class="para_h_name_and_add">Hospital Name & Address *</p>
          </section>
          <section class="section2">
            <section class="inside_section2">
              <section class="inside_section2A">
                <input class="input_hname_and_address" type="text" name="hospital_name" id=""/>
              </section>
              <section class="inside_section2B">
                <input class="input_p_name" type="text" name="patient_name" id=""/>
                <section class="para_b_group">Blood Group *</section>
                <select class="select_b_group" name="blood_group">
                  <option>Select</option>
                  <option>A+</option>
                  <option>B+</option>
                  <option>O+</option>
                  <option>A-</option>
                  <option>B-</option>
                  <option>O-</option>
                  <option>AB+</option>
                  <option>AB-</option>
                  <option>A</option>
                </select>
              </section>
            </section>
          </section>
          <section class="section_para_city_and_d_name">
            <p class="para_city">City *</p>
            <p class="para_dr_name">Doctor Name *</p>
          </section>
          <section class="section4">
            <select class="select_city" name="city">
              <option>Select</option>
              <option>Mumbai</option>
              <option>Delhi</option>
              <option>Bangalore</option>
              <option>Chennai</option>
              <option>Hyderabad</option>
              <option>Ahmedabad</option>
              <option>Kolkata</option>
              <option>Surat</option>
              <option>Pune</option>
              <option>Jaipur</option>
              <option>Lucknow</option>
              <option>Kanpur</option>
              <option>Nagpur</option>
              <option>Visakhapatnam</option>
              <option>Indore</option>
              <option>Thane</option>
              <option>Bhopal</option>
              <option>Madurai</option>
              <option>Patna</option>
              <option>Vadodara</option>
              <option>Ghaziabad</option>
              <option>Ludhiana</option>
              <option>Agra</option>
              <option>Nashik</option>
              <option>Faridabad</option>
              <option>Rajkot</option>
              <option>Meerut</option>
              <option>Aurangabad</option>
              <option>Dhanbad</option>
              <option>Amritsar</option>
              <option>Navi Mumbai</option>
              <option>Allahabad</option>
              <option>Ranchi</option>
              <option>Howrah</option>
              <option>Jabalpur</option>
              <option>Gwalior</option>
              <option>Jodhpur</option>
              <option>Guwahati</option>
              <option>Kota</option>
              <option>Chandigarh</option>
              <option>Thiruvananthapuram</option>
              <option>Solapur</option>
              <option>Noida</option>
              <option>Jamshedpur</option>
              <option>Bhilai</option>
              <option>Firozabad</option>
              <option>Kochi</option>
              <option>Durgapur</option>
              <option>Raniganj</option>
              <option>Asansol</option>
              <option>Burdwan</option>
            </select>
            <input class="input_dr_name" type="text" name="doctor_name" id=""/>
          </section>
        </fieldset>
        <fieldset class="fieldset">
          <legend class="form_legend">LOGIN INFORMATION</legend>


          <section class="info_section1">
            <p class="para_contact_name">Contact Name *</p>
            <p class="para_other_message">Other Message *</p>
          </section>
          <section class="info_section2">
            <section class="inside_info_section2">
              <section class="inside_info_section2A">
                <input class="input_other_message" type="text" name="other_message" id=""/>
              </section>
              <section class="inside_section2B">
                <input class="input_contact_name" type="text" name="contact_name" id=""/>
                <section class="para_contact_email">Contact Email ID *</section>
                <input class="input_email" type="email" name="contact_email" id=""/>
              </section>
            </section>
          </section>
          <section class="section_para_contact_and_when_required">
            <p class="para_contact_number">Contact Number * </p>
            <p class="para_when_required">When Required *</p>
          </section>
          <section class="info_section4">
            <input class="input_contact_number" type="text" name="contact_number" id=""/>
            <input class="input_when_required" type="date" name="when_required" id=""/>
          </section>
        </fieldset>
        <div class="captcha"><p style="color:red; text-align:center; line-height:75px;">
      	<?php

				echo @$_GET['msg'];

		?></p></div>
        <div class="checkbox1">
          <input class="input_checkbox" type="checkbox" name="checkbox" value="I agree to all terms & conditions" id=""/>
          <p class="para_checkbox">I agree to have my contact details broadcasted to the registered donors of BloodBankIndia.net</p>
        </div>
        <section class="submit">
          <input class="register" type="submit" name="submit" value="Submit Request"/>
        </section>
      </form>
    </div>
    <div class="mainB"> 
        	<div class="mainB1">
            	<h2 class="mainB1_heading">Search Donor</h2>
                
            	<form class="mainB1_form">
            	<section class="search_donor_section">
                	<select class="search_donor_input" name="blood_group">
                	<option>Select Blood Group</option>
                  	<option>A+</option>
                  	<option>B+</option>
                  	<option>O+</option>
                  	<option>A-</option>
                  	<option>B-</option>
                  	<option>O-</option>
                  	<option>AB+</option>
                  	<option>AB-</option>
                  	<option>A</option>
                </select>
                </section>
                <section class="search_donor_section">
                	<select class="search_donor_input" name="blood_group">
                	<option>Select City Name</option>
                  	<option>A+</option>
                  	<option>B+</option>
                  	<option>O+</option>
                  	<option>A-</option>
                  	<option>B-</option>
                  	<option>O-</option>
                  	<option>AB+</option>
                  	<option>AB-</option>
                  	<option>A</option>
                </select>
                </section>
                <section class="search_donor_section">
                	<select class="search_donor_input" name="blood_group">
                	<option>Select Gender</option>
                  	<option>Male</option>
                  	<option>Feamle</option>
                </select>
                </section>
                <section class="search_donor_section">
                	<select class="search_donor_input" name="blood_group">
                	<option>Select Locatilty</option>
                  	<option>A+</option>
                  	<option>B+</option>
                  	<option>O+</option>
                  	<option>A-</option>
                  	<option>B-</option>
                  	<option>O-</option>
                  	<option>AB+</option>
                  	<option>AB-</option>
                  	<option>A</option>
                </select>
                </section>
                <section class="search_donor_section">
                <input class="search_donor_submit" name="search" type="button" value="Search"> 
                </section>
            </form>
            </div>
            
            <a href="index_register.php">
            <div class="mainB2" align="center">
            <p>Donors Register Now !</p>
            </div>
            </a>
            
            <div class="mainB3">
            	<h3>PROMOTED BY</h3>
                <img src="images/share-for-gods.jpg"/>
                <p class="reg">/////////////////////////////////////////////////////////////////////////////////////</p>
                 <h3>SPONSORED BY</h3>
                 <p align="center" class="para_advertise">Will be updated soon..</p>
                <img src="images/ab.jpg" style="border-radius:7px; width:268px; height:367px;"/> 
            </div>
         

    		
    </div>
    
  </div>

</div>
</body>
 <?php
  	require"footer.php";
  ?>
</html>
