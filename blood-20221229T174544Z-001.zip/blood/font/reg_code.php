<?php

session_start();
	include "db_con.php";
	//$obj=new help();
?>
<?php
	  	
		if($_SERVER['REQUEST_METHOD']=="POST")
		{
		$name=$_POST['name'];
		$email=$_POST['email'];
		$password=$_POST['password'];
		$con_password=$_POST['con_password'];
		$date_of_birth=$_POST['date_of_birth'];
		$gender=$_POST['gender'];
		$blood_group=$_POST['blood_group'];
		$weight=$_POST['weight'];
		$feedback=$_POST['feedback'];
		$residence_phone=$_POST['residence_phone'];
		$mobile=$_POST['mobile'];
		$address=$_POST['address'];
		$city=$_POST['city'];
		
			
		$sql="insert into register_donor values('NULL','".$name."','".$email."','".$password."','".$con_password."','".$date_of_birth."','".$gender."','".$blood_group."','".$weight."','".$feedback."','".$residence_phone."','".$mobile."','".$address."','".$city."')";
		
		mysql_query($sql);
	}
	 header("location:register.php?msg1=Thank you to register as a donor...");
	
	  ?>