<?php
	class contact_us
	{
		function contact_us()
		{
			mysql_connect("localhost","root","");
			mysql_select_db("blood_bank");
		}	
	}
?>