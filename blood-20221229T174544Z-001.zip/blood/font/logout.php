<?php
session_start();
$_SESSION['user']="";

	if($_SESSION['user']=="")
	{
		header("location:index.php");
		
	}


?>