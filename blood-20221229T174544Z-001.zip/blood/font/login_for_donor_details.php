<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Online Blood Bank</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/login_for_index.css"/>
<body>
<div class="wrap">
<?php
	require"header.php";
?>
<?php
	require"login_for_index.php";
?>

</div>
<?php
	require"footer.php";
?>
</body>
</html>
