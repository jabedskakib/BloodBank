<?php
	include"connection.php";
	$obj=new help;
			
	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		$patient_name=$_POST['patient_name'];
		$hospital_name=$_POST['hospital_name'];
		$blood_group=$_POST['blood_group'];
		$doctor_name=$_POST['doctor_name'];
		$city=$_POST['city'];
		$contact_name=$_POST['contact_name'];
		$other_message=$_POST['other_message'];
		$contact_email=$_POST['contact_email'];
		$contact_number=$_POST['contact_number'];
		$when_required=$_POST['when_required'];
		$checkbox=$_POST['checkbox'];
		
			if(empty($patient_name))
		{
			header("location:main_request_blood.php?msg=Please enter the patient name");
		}
		
		else if(empty($hospital_name))
		{
			header("location:main_request_blood.php?msg=Please enter the hospital name");
		}

		else if(empty($blood_group))
		{
			header("location:main_request_blood.php?msg=Please select your blood group");
		}
		else if(empty($doctor_name))
		{
			header("location:main_request_blood.php?msg=Please enter the doctor name");
			
		}
		else if(empty($city))
		{
			header("location:main_request_blood.php?msg=Please select your city");
		}
		else if(empty($contact_name))
		{
			header("location:main_request_blood.php?msg=Please enter your contact name");
		}
		else if(empty($contact_email))
		{
			header("location:main_request_blood.php?msg=Please enter your contact email");
		}
		else if(!filter_var($contact_email, FILTER_VALIDATE_EMAIL))
		{
			header("location:main_request_blood.php?msg=Please enter a valid email address");
		}
		else if(empty($contact_number))
		{
			header("location:main_request_blood.php?msg=Please enter your contact number");
		}
		else if(empty($when_required))
		{
			header("location:main_request_blood.php?msg=Please select the date when required");
		}
		else if(empty($checkbox))
		{
			header("location:main_request_blood.php?msg=This field is required *");
		}
 
		else{
		$sql="insert into blood_request values('NULL','".$patient_name."','".$hospital_name."','".$blood_group."','".$doctor_name."','".$city."','".$contact_name."','".$other_message."','".$contact_email."','".$contact_number."','".$when_required."','".$checkbox."')";
			//echo $sql;exit;
		mysql_query($sql);
		header("location:request_blood.php");
	}
	}
?>