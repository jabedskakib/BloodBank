
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>About Us</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/about_us.css"/>
<body>
<div class="wrap">
<?php
	require"login_home_header.php"; 
?>
<?php
	require"about_us.php"; 
?>

</div>
<?php 
	require"footer.php";
?>
</body>
</html>
