<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Indian Blood Bank</title>
<link type="text/css" rel="stylesheet" href="stylesheet/index.css"/>
</head>

<body>
<?php
include"login_home_header.php";
?>
<div id="main">
<?php
	include"home.php";
?>

<?php
include"footer.php";
?>
    </div>
</body>
</html>