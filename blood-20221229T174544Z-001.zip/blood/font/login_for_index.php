

<div class="main">
    <div class="mainA">
      <h2 class="mainA_heading" align="center">Please Login to use this service.</h2>
  
      <form class="mainA_form" method="post" action="login_code_for_index.php">
        <fieldset class="fieldset">
          <legend class="form_legend">Login-Info</legend>
          <section class="section1">
            <p class="para_email">Email ID *</p>
            <p class="para_password">password*</p>
          </section>
          <section class="section2">
            <section class="inside_section2">
              <section class="inside_section2A">
                
                <input class="input_full_name" type="password" name="password" id=""/>
                
                
               
                <section class="section_captcha1">
                  <p style="color:red; text-align:center; line-height:75px;">
                    <?php
				echo @$_GET['msg'];
			?>
                  </p>
                </section>
              </section>
              <section class="inside_section2B">
                <input class="input_full_name" type="email" name="user" id=""/>
                <input class="login" type="submit" name="submit" value="Login"/>
                <section class="para_email_ID"></section>
                
              </section>
            </section>
          </section>
        </fieldset>
        
      </form>
    </div>
    
  </div>
