<div class="main_else">
    <div class="result_else">
      <p><b>Sorry !</b> No results found in city <b><?php echo $city ?></b>, for blood group <b> " <?php echo $blood_group?> "</b></p>
    </div>
    </div>