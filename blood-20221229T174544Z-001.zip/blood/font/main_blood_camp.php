<?php

	
	include "db_con.php";
	//$obj=new help();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Request Blood</title>
</head>
<link rel="stylesheet" type="text/css" 
href= "stylesheet/contact_us2.css"/>
<body>
<div class="wrap">
<?php
	require"header.php";
?>

<div class="main">
	<div class="blank"></div>
    <div class="mainA">
      <h2 class="mainA_heading">Blood Camp</h2>
	  <?php
			$sql="select * from blood_camp";
			$rs=mysql_query($sql);
			while($d=mysql_fetch_array($rs))
			{
			?>
	  
	  <div style="background:#cccccc; width:200px; border:1px solid green; margin-left:10px; padding-top:3px; margin-top:10px; float:left; height:150px; border-radius:10px 10px 10px 10px;">
	  
	<table width="160" border="0">
	  	<tr>
			<td width="38" align="center"><?php echo $d['address'];?></td>
		</tr>
		<tr>
			<td width="38" align="center"><?php echo $d['district'];?></td>
		</tr>
		<tr>
			<td width="38" align="center"><?php echo $d['city'];?></td>
		</tr>
		<tr>
			<td width="38" align="center"><?php echo $d['date'];?></td>
		</tr>
		<tr>
			<td width="38" align="center"><?php echo $d['phone_number'];?></td>
		</tr>
	    <tr>
		 <td align="center"><?php echo $d['email_id'];?></td>
		</tr>
		
	  	
	</table>
	</div>
	<?php
		}
		
		?>
	  
    </div>

  
      
  </div>
	 
</div>
</div>
<?php
  	require"footer.php";
  ?>
</body>
 
</html>

