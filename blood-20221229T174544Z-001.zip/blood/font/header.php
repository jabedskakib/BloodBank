<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login_Header</title>
<link type="text/css" rel="stylesheet" href="stylesheet/login.css"/>
</head>

<body>

<header class="header">
  <div class="header1">
    <div class="header1A"> </div>
    <div class="header1B">
      <div class="header1B1"><img src="images/bbi-logo.png"/></div>
      <div class="header1B2"> </div>
      <div class="header1B3">
        <div class="header1B3A">
          <div class="header1B3A1">
            <p class="para1B3A1">Email/Mobile No</p>
          </div>
          <div class="header1B3A2">
            <p class="para1B3A2">Password</p>
            </div>
        </div>
        <div class="header1B3B">
          <div class="header1B3B1">
          
            <form method="post" action="login_code.php">
              <input class="input1B3B1" type="email" name="email">
          </div>
          <div class="header1B3B2">
              <input class="input1B3B2" type="password" name="password">
          </div>
          <div class="header1B3B3">
              <input class="input1B3B3" type="submit" value="Login">
            </form>
            <div><div style='color:red;font-weight:bold;width:260px;height:20px;'><p style='text-align:center;'><?php echo @$_GET['msg'];?></p></div>
    </div>

          </div>
          <div class="header1B3B4">
            <p class="para_1B3B4">|</p>
          </div>
          <div class="header1B3B4">
            <div class="header1B3B5">
              <p class="para1B3B5"><a href="register.html" class="a_link1B3B5">Register</a></p>
            </div>
          </div>
        </div>
        <div class="header1B3C">
          <div class="header1B3C1">
            <p class="para1B3C1">Forgot password?</p>
          </div>
        </div>
      </div>
    </div>
    <div class="header1C"> </div>
  </div>
  <div class="header2">
    <div class="header2A">
      <div class="header2A1"> </div>
      <div class="header2A2"> </div>
    </div>
    <div class="menubar" style="background-color:#0033FF;">
      <ul>
       <a href="index.php"> <li>HOME</li></a>
        <a href="main_about_us.php"><li>ABOUT US</li></a>
        <a href="register.php"><li>REGISTER AS DONOR</li></a>
        <a href="index_search.php"> <li>SEARCH DONORS</li></a>
       <a href="main_blood_camp.php"><li>BLOOD CAMP</li></a>
        <a href="main_galary.php"><li>GALARY</li></a>
       <a href="main_contact_us.php"> <li>CONTACT US</li></a>
	   
      </ul>
    </div>
    <div class="header2C">
      <div class="header2C1"> </div>
      <div class="header2C2"> </div>
    </div>
  </div>
</header>
</body>
</html>