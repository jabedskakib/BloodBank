<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Indian Blood Bank</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/founded.css"/>
<body>
<div class="main_if">
  <?php
 	include"connection.php";
	$obj=new help;
	$blood_group=$_REQUEST['blood_group'];
	$city=$_REQUEST['city'];
				
				
	$query="select * from registeration where blood_group='".$blood_group."' and city='".$city."'";
	$run=mysql_query($query);
	//echo $query;exit();
?>
    <?php
			$count=0;
			if($d=mysql_fetch_array($run)>0)
				{ 
					$count=$count+1;
					//echo $query;exit();
				?>
    				<h2 class="heading">Search Results</h2>
                	<div class="count_result">
                  <p><?php echo $count ?>results showing in <b><?php echo $city ?></b>, for blood group <b> " <?php echo $blood_group?> "</b></p>
                </div>
               
    	<?php 
			while($d=mysql_fetch_array($run)>0)
				{ 
					$count=$count+1;
					$name=$d['name'];
					$city=$d['city'];				
		?>
    				<div class="result_if">
      <div class="_blood_name">
        <div class="blood_group"><?php echo $blood_group?></div>
        <div class="name"><?php echo $name ?> </div>
      </div>
      <div class="loaction">
        <p class="p_area">Aria</p>
      </div>
      <div class="line">
        <p>..................................................................................................................................................................................................................................................................................................................................................................................................................................................................</p>
      </div>
      <div class="date">
        <p class="p_date">Last blood donated date : Yet to donate</p>
      </div>
      <div class="details"> <a href="send_email.php">
        <div class="mail">
          <p><span><img src="images/message.png"/></span>Send Mail</p>
        </div>
        </a> <a href="login_for_donor_details.php">
        <div class="view_details"> <span><img src="images/view.png"/></span>View Contact Details </div>
        </a> </div>
    </div>
 		  <?php } ?>
          </div>

  <?php } 
		
    				
else 
{
	require"not_found.php";			
}?>
   
</body>
</html>
