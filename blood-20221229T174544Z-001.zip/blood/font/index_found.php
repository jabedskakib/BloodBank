<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Result | Found</title>
</head>
<body>
<?php
	require"header.php";
?>
<?php
	include"search_result.php";
?>

</body>
</html>
