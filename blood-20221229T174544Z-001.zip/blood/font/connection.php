<?php
class help
{
	function help()//constructor
	{
		$con=mysql_connect("localhost","root","");
		mysql_select_db("indian_blood_bank");
	}
}
?>