<div class="main">
<div class="mainA">
<div class="mainA1"> </div>
<div class="mainA2">
<div class="mainA2A">
  <p class="paraA2A">Search Blood Donors</p>
</div>
<div class="mainA2B">
<div class="mainA2B1">
<div class="mainA2B1A">
<ul class="ul_mainA2B1">
<li class="li_mainA2B1">Blood Group *</li>
<li class="li_mainA2B1">City *</li>
</div>
<div class="mainA2B1B">

  <form action="index_found.php" method="post">
    <ul>
      <li class="list1">
        <select class="selectA2B2" name="blood_group">
          <option>Select</option>
          <option>A+</option>
          <option>B+</option>
          <option>O+</option>
          <option>A-</option>
          <option>B-</option>
          <option>O-</option>
          <option>AB+</option>
          <option>AB-</option>
          <option>A</option>
        </select>
      </li>
      <li class="list2">
        <select class="selectA2B2" name="city">
          <option>Select</option>
		   <option>Mumbai</option>
              <option>Delhi</option>
              <option>Bangalore</option>
              <option>Chennai</option>
              <option>Hyderabad</option>
              <option>Ahmedabad</option>
              <option>Kolkata</option>
              <option>Surat</option>
              <option>Pune</option>
			  <option>Tamluk</option>
			  <option>Contai</option>
			  <option>Holdia</option>
			  <option>Medinipur</option>
              <option>Jaipur</option>
              <option>Lucknow</option>
              <option>Kanpur</option>
              <option>Nagpur</option>
              <option>Visakhapatnam</option>
              <option>Indore</option>
              <option>Thane</option>
              <option>Bhopal</option>
              <option>Madurai</option>
              <option>Patna</option>
              <option>Vadodara</option>
              <option>Ghaziabad</option>
              <option>Ludhiana</option>
              <option>Agra</option>
              <option>Nashik</option>
              <option>Faridabad</option>
              <option>Rajkot</option>
              <option>Meerut</option>
              <option>Aurangabad</option>
              <option>Dhanbad</option>
              <option>Amritsar</option>
              <option>Navi Mumbai</option>
              <option>Allahabad</option>
              <option>Ranchi</option>
              <option>Howrah</option>
              <option>Jabalpur</option>
              <option>Gwalior</option>
              <option>Jodhpur</option>
              <option>Guwahati</option>
              <option>Kota</option>
              <option>Chandigarh</option>
              <option>Thiruvananthapuram</option>
              <option>Solapur</option>
              <option>Noida</option>
              <option>Jamshedpur</option>
              <option>Bhilai</option>
              <option>Firozabad</option>
              <option>Kochi</option>
              <option>Durgapur</option>
              <option>Raniganj</option>
              <option>Asansol</option>
              <option>Burdwan</option> 	
          
        </select>
      </li>
      <li>
        <div>
          <input class="divstyle" type="submit" value="search" name="search"/>
          </div>
      </li>
    </ul>
</div>
<div class="mainA2B1C">
  <input type="checkbox" name="checkbox" style="margin-top:12px; float:left"/>
  <p class="para_mainA2B1C">I have read and agree to abide by the <a style="color:white" href="#">terms and conditions</a></p>
</div>
</form>
	
</div>
</div>
<div class="mainA2B3">
  <div class="mainA2B3A">
    <p style="margin-top:10px; color:#CCC">...................................................................................................................................................................</p>
  </div>
  <div class="mainA2B3B">
    <ul>
      <li class="mainA2B3B_list1
">Want to become a blood donor?</li>
      <li>
        <div class="mainA2B3B_list2_divstyle"><a class="mainA2B3B_list2_link_style" href="register.html">
          <p class="mainA2B3B_para_style">Register Now</p>
        </div>
      </li>
      </a>
    </ul>
  </div>
</div>
</div>
<div class="mainA3"> </div>
</div>
<div class="mainB">
  <div class="mainB1">
    <div class="mainB1_div"> <img src="images/ico-1.png"/> </div>
    <ul>
      <li>3</li>
      <li>9</li>
      <li>0</li>
      <li>0</li>
      <li>+</li>
      <p class="para_mainB1_ul">Blood Donors</p>
    </ul>
  </div>
  <div class="mainB2">
    <div class="mainB2_div1"> <img src="images/ico-2.png"/> </div>
    <div class="mainB2_div2">
      <ul>
        <li>1</li>
        <li>5</li>
        <li>0</li>
        <li>0</li>
        <li>+</li>
        <p class="para_mainB2_ul">Blood Requests</p>
      </ul>
    </div>
  </div>
  <div class="mainB3">
    <div class="mainB3_div1"> <img src="images/ico-3.png"/> </div>
    <div class="mainB3_div2">
      <ul>
        <li>1</li>
        <li>9</li>
        <li>0</li>
        <li>0</li>
        <li>+</li>
        <p class="para_mainB3_ul">Active Donors</p>
      </ul>
    </div>
  </div>
</div>
<div style="background:#cccccc; width:850px; height:300px; margin-left:220px; padding:20px;border:1px solid black; border-radius:10px 10px 10px 10px; float:left;">
  <?php

	$sql="select * from home";
	$rs=mysql_query($sql);
	while($d=mysql_fetch_array($rs))
	
	{
?>
  <h3><?php echo $d['title'];?></h3>
  <div style="width:100%; height:10px;"></div>
  <p><?php echo $d['details'];?> </p>
  <?php
	}
	
	
	?>
</div>
<div class="mainC"> </div>
</div>