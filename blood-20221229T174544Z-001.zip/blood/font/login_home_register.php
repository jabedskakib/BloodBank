<?php
	include"connection.php";
	$obj=new help;
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Registration</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/register.css"/>
<body>
<div class="wrap">
<?php
	require"login_home_header.php";
?>
 <?php
	require"register.php";
?>
</div>
<?php
  require"footer.php";
?>

</body>
</html>
