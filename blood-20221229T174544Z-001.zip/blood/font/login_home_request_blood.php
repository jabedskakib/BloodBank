
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Request Blood</title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheet/request_blood.css"/>
<body>
<div class="wrap">
<?php
	require"login_home_header.php";
?>

 <?php
	require"request_blood.php";
?>

</div>
</body>
 <?php
  	require"footer.php";
  ?>
</html>
