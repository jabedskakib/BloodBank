<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Exam | Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/exam_login.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
</head>
<body>
<div class="main">
  <?php
  	include"header.php";
  ?>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Please login to start your exam.</span></h2>
          <h3 style="color:red;"><span> <div><?php echo @$_GET['msg'];?></span> </h3>
        </div>
        <div class="article">
          <form method="post" id="sendemail" action="exam_login_code.php">
          <fieldset>
          <legend style="font-size:18px; margin:10px; padding:5px">Login-Information</legend>
            <ol>
              <li>
                <label for="email">E-Mail ID*</label>
                <input type="email" id="email" name="email" class="text" />
              </li>
              <li>
                <label for="password">Password*</label>
                <input type="text" id="website" name="password" class="text" />
              </li>
              <li>
                <input type="image" name="imageField" id="imageField" src="images/submit.gif" class="send" value="Login" />
                <div class="clr"></div>
              </li>
            </ol>
            </fieldset>
          </form>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <?php
  	include"footer.php";
  ?>
</div>
<div align=center>This template  downloaded form <a href='http://all-free-download.com/free-website-templates/'>free website templates</a></div></body>
</html>
