-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 14, 2018 at 08:12 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_blood_bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutus`
--

CREATE TABLE `aboutus` (
  `id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aboutus`
--

INSERT INTO `aboutus` (`id`, `title`, `details`) VALUES
(1, 'SAVE LIFE BLOOD BANK', 'We are want to change a think, If you think you can, you really can');

-- --------------------------------------------------------

--
-- Table structure for table `blood_bank`
--

CREATE TABLE `blood_bank` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `bank_add` varchar(255) NOT NULL,
  `bank_email` varchar(255) NOT NULL,
  `bank_phone` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood_bank`
--

INSERT INTO `blood_bank` (`id`, `bank_name`, `bank_add`, `bank_email`, `bank_phone`) VALUES
(2, 'Malda Blood Bank', 'Malda', 'malda_blood@gmail.com', '9732584457'),
(3, 'contai blood bank', 'contai', 'con@gmail.com', '0322031455');

-- --------------------------------------------------------

--
-- Table structure for table `blood_camp`
--

CREATE TABLE `blood_camp` (
  `id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `phone_number` varchar(11) NOT NULL,
  `email_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood_camp`
--

INSERT INTO `blood_camp` (`id`, `address`, `district`, `city`, `date`, `phone_number`, `email_id`) VALUES
(1, 'Barrackpur,Chiriamore', 'North 24 pgs', 'Barrackpur', '2017-12-02', '9732587444', 'bkp@gmail.com'),
(2, 'nadia', 'nadia', 'Ranaghat', '2017-12-04', '1234567890', 'nadia@gmail.com'),
(3, 'TAMLUK SABUJ SANGHA', 'purba medinipur', 'TAMLUK', '2017-12-30', '8574787444', 'tamluksabujsangha@gmail.com'),
(4, 'TAMLUK', 'purba medinipur', 'TAMLUK', '2017-12-03', '8974578958', 'tamluk@gamil.com');

-- --------------------------------------------------------

--
-- Table structure for table `blood_master`
--

CREATE TABLE `blood_master` (
  `id` int(11) NOT NULL,
  `blood_group` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood_master`
--

INSERT INTO `blood_master` (`id`, `blood_group`) VALUES
(1, 'ab+'),
(2, 'B-'),
(3, 'A+'),
(5, 'o+');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `add` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `add`, `details`) VALUES
(4, 'SAVE LIFE BLOOD BANK', 'savelife@gmail.com', '8389853274', 'TAMLUK,PURBA MEDINIPUR', 'Give blood. Save life.');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `description`, `file_name`) VALUES
(15, 'CONTAI BLOOD CAMP', '31vzsbe05mega-GAH2D3C4A3jpgjpg.jpg'),
(16, 'WEST BENGAL POLICE DONATE BLOOD', '65.jpg'),
(17, 'TAMLUK BLOOD CAMP', '1.jpg'),
(20, 'INDIAN ARMY DONATE BLOOD', '2016_1$largeimg15_Friday_2016_235704148.jpg'),
(22, 'BLOOD CAMP FOR VOLUNTEERS', 'top6.jpg'),
(23, 'Blood Donation Camp Awareness Rally', 'blood-donation.WB_.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE `home` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `details` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`id`, `title`, `details`) VALUES
(1, 'Blood', 'Blood is universally recognized as the most precious element that sustains life. It saves innumerable lives across the world in a variety of conditions. The need for blood is great - on any given day, approximately 39,000 units of Red Blood Cells are need');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `user`, `password`) VALUES
(1, 'user', 'pass');

-- --------------------------------------------------------

--
-- Table structure for table `register_donor`
--

CREATE TABLE `register_donor` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `con_password` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` varchar(255) NOT NULL,
  `blood_group` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `feedback` varchar(255) NOT NULL,
  `residence_phone` varchar(10) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register_donor`
--

INSERT INTO `register_donor` (`id`, `name`, `email`, `password`, `con_password`, `date_of_birth`, `gender`, `blood_group`, `weight`, `feedback`, `residence_phone`, `mobile`, `address`, `city`) VALUES
(1, 'RAM DAS', 'ram@gmail.com', 'ar', 'ar', '2017-04-19', 'male', 'B+', '55', 'Regular Donor', '12345678', '1278945612', 'Main road', 'Pune'),
(2, 'shyam Mallick', 'shyam@gmail.com', 'ar', 'ar', '2017-04-19', 'male', 'A+', '66', 'Yet to Donate', '78945612', '7894561230', 'Station Road', 'Thane'),
(3, 'Raj Bose', 'raj@gmail.com', 'aa', 'aa', '2017-03-31', 'male', 'A+', '88', 'Regular Donor', '569874123', '9875641230', 'jasodapur', 'Thane'),
(4, 'aparna sahoo', 'aparna@gmail.com', '123', '123', '1990-10-31', 'female', 'B+', '42', 'Yet to Donate', '9732832835', '7797247080', 'sultanpur', 'kolkata'),
(5, 'suman sahoo', 'sumansahoo987@gmail.com', '123', '123', '1998-01-13', 'male', 'B+', '20', 'Yet to Donate', '8967510495', '8389853275', 'vill-sultanpur', 'TAMLUK'),
(6, 'akib jabed', 'akibjabed@gmail.com', '123', '123', '1997-01-17', 'male', 'B+', '73', 'Regular Donor', '0322812487', '8158824900', 'bohichberia', 'Tamluk'),
(7, 'puja mirdha', 'puja@gmail.com', 'pass', '123', '1999-07-13', 'female', 'AB+', '18', 'Yet to Donate', '5454885454', '9874587456', 'kanaidighi', 'Contai'),
(8, 'suparna mirdha', 'suparna@gmail.com', '123', '123', '1998-07-28', 'female', 'AB+', '19', 'Regular Donor', '8961475475', '8967510495', 'kanaidighi', 'Contai'),
(19, 'susanta khanra', 'susantakhanra@gmail.com', '123456', '12345', '1996-11-29', 'male', 'B+', '55', 'Regular Donor', '8116609743', '8116609743', 'srirampur', 'Tamluk'),
(20, 'sk akib jabed', 'jabedskakib@gmail.com', '12345', '12345', '1995-01-01', 'male', 'B+', '80', 'Regular Donor', '8158824900', '8158824900', 'bohichberia', 'Tamluk'),
(21, 'akash sau', 'akashsau9@gmail.com', '12345', '12345', '1995-02-02', 'male', 'B+', '50', 'Regular Donor', '9547649568', '9547649568', 'kanaidighi', 'Tamluk'),
(22, 'tanmoy kayal', 'tanmoykayal@gmail.com', '12345', '12345', '1996-05-01', 'male', 'B+', '66', 'Regular Donor', '9800729484', '9800729484', 'south 24 pargana', 'Tamluk');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutus`
--
ALTER TABLE `aboutus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blood_bank`
--
ALTER TABLE `blood_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blood_camp`
--
ALTER TABLE `blood_camp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blood_master`
--
ALTER TABLE `blood_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register_donor`
--
ALTER TABLE `register_donor`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutus`
--
ALTER TABLE `aboutus`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `blood_bank`
--
ALTER TABLE `blood_bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `blood_camp`
--
ALTER TABLE `blood_camp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `blood_master`
--
ALTER TABLE `blood_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `home`
--
ALTER TABLE `home`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `register_donor`
--
ALTER TABLE `register_donor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
